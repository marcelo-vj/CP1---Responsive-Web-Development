export const Header = () => {
  return (
    <header>
      <p>Header</p>
    </header>
  )
}
